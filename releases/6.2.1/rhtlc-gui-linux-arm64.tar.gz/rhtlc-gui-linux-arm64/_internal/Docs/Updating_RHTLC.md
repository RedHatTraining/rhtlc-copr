# How to Update RHTLC

This guide covers updating an existing RHTLC client install (v5.1.0 or later; **6.0.0** ships onedir `.tar.gz`/`.zip` bundles — extract the full directory when updating standalone downloads).

For first-time installs, see the Instructor Guide / Installation Guide that shipped with your course materials (not linked from this in-app dialog).

**Download location for end users:** all installers and standalone binaries are published to the Apps binary repository:

[ws-ole/binary](https://pypi.apps.tools-na.prod.nextcle.com/service/rest/repository/browse/ws-ole/binary/)

Direct file URLs use the same host under `/repository/ws-ole/binary/<filename>`.

Because installs differ (COPR, Homebrew, Windows installer, or a standalone binary), use the section below that matches how *you* installed RHTLC. The GUI **How to Update** button opens this same guide.

---

## Check whether an update is available

### GUI (v5.1.0+)

On startup, RHTLC compares your installed version to the published version on Nexus. If a newer version is available, a banner appears at the top of the main window with a **How to Update** button.

You can also check manually:

1. Open **Help**
2. Click **Check for Updates**
3. If an update is available, click **How to Update** on the banner

### CLI

```bash
rhtlc check-update
rhtlc --version
```

---

## Package-manager installs (recommended)

Use these steps if you installed via COPR (Linux) or Homebrew (macOS).

### Linux (COPR)

```bash
sudo dnf upgrade rhtlc
rhtlc --version
```

If the COPR repo is not enabled yet:

```bash
sudo dnf copr enable tmichett/RHTLC
sudo dnf upgrade rhtlc
```

### macOS (Homebrew)

Homebrew 6+ requires **explicit trust** for third-party taps. The
`RedHatTraining/rhtlc` tap is not an official Homebrew core tap, so installs and
upgrades can fail until you trust the formula, cask, and/or tap.

**Recommended upgrade sequence** (re-trust is safe to re-run anytime):

```bash
# Re-trust the RHTLC packages and tap (needed after some Homebrew upgrades)
brew trust --formula redhattraining/rhtlc/rhtlc
brew trust --cask redhattraining/rhtlc/rhtlc-gui
brew trust --tap redhattraining/rhtlc

brew update
brew upgrade rhtlc
brew upgrade --cask rhtlc-gui

rhtlc --version
```

If `brew upgrade` reports that the tap or package is not trusted / cannot be
loaded, run the three `brew trust` lines again, then retry `brew update` and
`brew upgrade`.

**Optional checks:**

```bash
brew trust                    # list currently trusted taps/formulae/casks
brew doctor                   # may warn about untrusted third-party taps
```

After upgrading, quit and relaunch the **RHTLC GUI** if it was already open.

### Windows (installer)

1. Open the binary repository browse page:  
   [ws-ole/binary](https://pypi.apps.tools-na.prod.nextcle.com/service/rest/repository/browse/ws-ole/binary/)
2. Download the latest `RHTLC-{VERSION}-Setup.exe` (6.0.0+: installs onedir GUI + CLI trees)
3. Run the setup executable and follow the installer prompts.
4. Confirm with:

```powershell
rhtlc --version
```

---

## Standalone / portable binaries

Use this path when package managers are blocked by policy (no root/admin install).

1. Open the binary repository browse page:  
   [ws-ole/binary](https://pypi.apps.tools-na.prod.nextcle.com/service/rest/repository/browse/ws-ole/binary/)
2. Download the onedir archive for your platform (`.tar.gz` on Linux/macOS CLI, `.zip` on Windows).
3. Extract the archive and replace your existing bundle directory (keep the full tree — includes `_internal/` and `rhtlc-wstunnel`).
4. Make the main executable inside the bundle executable if needed: `chmod +x rhtlc-linux-x86_64/rhtlc-linux-x86_64`

| Platform | Typical standalone files (6.0.0+) |
|----------|-----------------------------------|
| Linux | `rhtlc-linux-x86_64.tar.gz`, `rhtlc-gui-linux-x86_64.tar.gz`, arm64 equivalents |
| macOS | `rhtlc-macos-*.tar.gz`, `rhtlc-gui-macos-*.zip` |
| Windows | `rhtlc-windows-x86_64.zip`, `rhtlc-gui-windows-x86_64.zip` |

**Notes:**

- Some features (PATH install, URL-handler registration, system-wide shortcuts) may be unavailable without admin rights.
- On macOS, remove quarantine after downloading a new `.app`:

```bash
xattr -cr RHTLC-GUI.app
```

---

## After updating

1. Confirm the version:

```bash
rhtlc --version
```

2. Optional: confirm the published version again:

```bash
rhtlc check-update
```

3. Restart the GUI if it was already open.
